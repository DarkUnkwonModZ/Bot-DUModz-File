package com.liteapk.dialog66;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class liteapkdialog {

    // ================= CONFIGURATION (HEX COLORS & TEXT) =================
    
    private static final String PREF_NAME = "liteapk_prefs";
    private static final String KEY_DONT_SHOW = "dont_show_dialog";

    // টেক্সট কনফিগ
    private static final String TXT_TITLE = "⭐LiteApks.Com⭐";
    private static final String TXT_BODY = "Exclusive Games And Apps Mods Only on\nLiteApks.Com 🌍\n\nCheck Modded Games & Apps 👻";
    private static final String TXT_FOOTER = "Join TG 👉 Private | LiteApks | Backup";
    private static final String TXT_TOGGLE = "Don't show again";
    
    // ক্রেডিট লজিক (Base64 for: Dark Unkwon ModZ)
    private static final String CR_ENC = "RGFyayBVbmt3b24gTW9kWg=="; 

    // লিংক কনফিগ
    private static final String URL_SITE = "https://liteapks.com";
    private static final String URL_GAMES = "https://liteapks.com/games";
    private static final String URL_APPS = "https://liteapks.com/apps";
    private static final String URL_TG_PRIVATE = "https://t.me/liteapks_private";
    private static final String URL_TG_BACKUP = "https://t.me/liteapks_backup";

    // হেক্স কালার কোড
    private static final String HEX_BG_START = "#0F2027";
    private static final String HEX_BG_END = "#000000";
    private static final String HEX_BORDER = "#FF4500";
    private static final String HEX_TITLE = "#00D2FF";
    private static final String HEX_WHITE = "#FFFFFF";
    private static final String HEX_HIGHLIGHT = "#FFD700";
    private static final String HEX_TOGGLE_OFF = "#FF0000";
    private static final String HEX_TOGGLE_ON = "#00FF00";
    private static final String HEX_CREDIT = "#555555"; // হালকা কালার ক্রেডিটের জন্য
    
    private static final String[] BTN_CLOSE_NORM = {"#FF512F", "#DD2476"}; 
    private static final String[] BTN_CLOSE_HOVR = {"#DD2476", "#FF512F"};
    private static final String[] BTN_VISIT_NORM = {"#00c6ff", "#0072ff"}; 
    private static final String[] BTN_VISIT_HOVR = {"#0072ff", "#00c6ff"};

    private static final int CORNER_RADIUS = 30;
    private static final int BORDER_WIDTH = 3;

    public static void show(final Context context) {
        // ১. ক্রেডিট সিকিউরিটি চেক
        String decodedCredit = new String(Base64.decode(CR_ENC, Base64.DEFAULT));
        if (!decodedCredit.equals("Dark Unkwon ModZ")) {
            Toast.makeText(context, "Security Alert: Unauthorized Modification!", Toast.LENGTH_LONG).show();
            return;
        }

        final SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_DONT_SHOW, false)) return;

        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        // মেইন লেআউট
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        int p = dpToPx(context, 25);
        card.setPadding(p, p, p, p);
        card.setGravity(Gravity.CENTER);

        // ব্যাকগ্রাউন্ড
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor(HEX_BG_START), Color.parseColor(HEX_BG_END)});
        bg.setCornerRadius(dpToPx(context, CORNER_RADIUS));
        bg.setStroke(dpToPx(context, BORDER_WIDTH), Color.parseColor(HEX_BORDER));
        card.setBackground(bg);

        // ২. টাইটেল
        TextView tvTitle = new TextView(context);
        tvTitle.setText(TXT_TITLE);
        tvTitle.setTextColor(Color.parseColor(HEX_TITLE));
        tvTitle.setTextSize(22);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        card.addView(tvTitle);

        // ৩. বডি টেক্সট (Games & Apps হাইলাইট লিংক ফিক্সড)
        TextView tvBody = new TextView(context);
        tvBody.setTextColor(Color.parseColor(HEX_WHITE));
        tvBody.setTextSize(16);
        tvBody.setGravity(Gravity.CENTER);
        tvBody.setPadding(0, dpToPx(context, 20), 0, dpToPx(context, 10));
        tvBody.setLineSpacing(dpToPx(context, 4), 1.1f);

        SpannableString bodySpan = new SpannableString(TXT_BODY);
        
        // নির্দিষ্টভাবে বডির "Games" এবং "Apps" এ লিংক সেট করা
        setLinkAtEnd(bodySpan, "Games", URL_GAMES, context, TXT_BODY);
        setLinkAtEnd(bodySpan, "Apps", URL_APPS, context, TXT_BODY);
        // মেইন সাইট লিংক
        setLink(bodySpan, "LiteApks.Com 🌍", URL_SITE, context, TXT_BODY);
        
        tvBody.setText(bodySpan);
        tvBody.setMovementMethod(LinkMovementMethod.getInstance());
        tvBody.setHighlightColor(Color.TRANSPARENT);
        card.addView(tvBody);

        // ৪. ফুটার লিংক
        TextView tvFooter = new TextView(context);
        tvFooter.setTextColor(Color.parseColor(HEX_WHITE));
        tvFooter.setTextSize(14);
        tvFooter.setGravity(Gravity.CENTER);
        tvFooter.setPadding(0, 0, 0, dpToPx(context, 20));

        SpannableString footerSpan = new SpannableString(TXT_FOOTER);
        setLink(footerSpan, "Private", URL_TG_PRIVATE, context, TXT_FOOTER);
        setLink(footerSpan, "LiteApks", URL_SITE, context, TXT_FOOTER);
        setLink(footerSpan, "Backup", URL_TG_BACKUP, context, TXT_FOOTER);

        tvFooter.setText(footerSpan);
        tvFooter.setMovementMethod(LinkMovementMethod.getInstance());
        card.addView(tvFooter);

        // ৫. সুইচ/টগল
        LinearLayout toggleBox = new LinearLayout(context);
        toggleBox.setGravity(Gravity.CENTER);
        toggleBox.setPadding(0, 0, 0, dpToPx(context, 15));

        TextView tvToggle = new TextView(context);
        tvToggle.setText(TXT_TOGGLE);
        tvToggle.setTextColor(Color.parseColor("#BBBBBB"));
        tvToggle.setPadding(0, 0, dpToPx(context, 10), 0);

        final Switch sw = new Switch(context);
        int[][] states = new int[][] { new int[] {-android.R.attr.state_checked}, new int[] {android.R.attr.state_checked} };
        int[] colors = new int[] { Color.parseColor(HEX_TOGGLE_OFF), Color.parseColor(HEX_TOGGLE_ON) };
        sw.setThumbTintList(new ColorStateList(states, colors));
        sw.setTrackTintList(new ColorStateList(states, colors));
        
        toggleBox.addView(tvToggle);
        toggleBox.addView(sw);
        card.addView(toggleBox);

        // ৬. বাটন সেকশন
        LinearLayout btnBox = new LinearLayout(context);
        btnBox.setOrientation(LinearLayout.HORIZONTAL);
        btnBox.setGravity(Gravity.CENTER);

        Button bClose = createBtn(context, "Close", BTN_CLOSE_NORM, BTN_CLOSE_HOVR);
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, dpToPx(context, 45), 1f);
        p1.setMargins(dpToPx(context, 5), 0, dpToPx(context, 5), 0);
        bClose.setLayoutParams(p1);
        bClose.setOnClickListener(v -> {
            if (sw.isChecked()) prefs.edit().putBoolean(KEY_DONT_SHOW, true).apply();
            dialog.dismiss();
        });

        Button bVisit = createBtn(context, "Visit LiteApks.Com", BTN_VISIT_NORM, BTN_VISIT_HOVR);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dpToPx(context, 45), 1.5f);
        p2.setMargins(dpToPx(context, 5), 0, dpToPx(context, 5), 0);
        bVisit.setLayoutParams(p2);
        bVisit.setOnClickListener(v -> openUrl(context, URL_SITE));

        btnBox.addView(bClose);
        btnBox.addView(bVisit);
        card.addView(btnBox);

        // ৭. ক্রেডিট সেকশন (নিচে হালকা কালারে)
        TextView tvCredit = new TextView(context);
        tvCredit.setText(decodedCredit); // Base64 থেকে আসা টেক্সট
        tvCredit.setTextColor(Color.parseColor(HEX_CREDIT));
        tvCredit.setTextSize(10);
        tvCredit.setGravity(Gravity.CENTER);
        tvCredit.setPadding(0, dpToPx(context, 15), 0, 0);
        card.addView(tvCredit);

        // ডায়ালগ শো লজিক
        dialog.setContentView(card);
        Window w = dialog.getWindow();
        if (w != null) {
            int width = (context.getResources().getDisplayMetrics().widthPixels * 90) / 100;
            w.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.getAttributes().windowAnimations = android.R.style.Animation_Dialog;
        }

        dialog.show();
    }

    // বাটন মেকার
    private static Button createBtn(Context ctx, String text, String[] norm, String[] hovr) {
        Button b = new Button(ctx);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);

        GradientDrawable gdNormal = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor(norm[0]), Color.parseColor(norm[1])});
        gdNormal.setCornerRadius(dpToPx(ctx, 15));

        GradientDrawable gdHover = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor(hovr[0]), Color.parseColor(hovr[1])});
        gdHover.setCornerRadius(dpToPx(ctx, 15));
        gdHover.setStroke(dpToPx(ctx, 2), Color.WHITE);

        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, gdHover);
        states.addState(new int[]{}, gdNormal);
        
        b.setBackground(states);
        return b;
    }

    // জেনারেল লিংক হেল্পার
    private static void setLink(SpannableString ss, String word, final String url, final Context ctx, String fullText) {
        int start = fullText.indexOf(word);
        if (start == -1) return;
        applySpan(ss, start, start + word.length(), url, ctx);
    }

    // বডির শেষের দিকের নির্দিষ্ট "Games, Apps" এর জন্য ফিক্সড হেল্পার
    private static void setLinkAtEnd(SpannableString ss, String word, final String url, final Context ctx, String fullText) {
        int start = fullText.lastIndexOf(word); // শেষের বারের occurrence ধরবে (Check Modded Games & Apps অংশ)
        if (start == -1) return;
        applySpan(ss, start, start + word.length(), url, ctx);
    }

    private static void applySpan(SpannableString ss, int start, int end, final String url, final Context ctx) {
        ss.setSpan(new ClickableSpan() {
            @Override public void onClick(View v) { openUrl(ctx, url); }
            @Override public void updateDrawState(TextPaint ds) {
                ds.setColor(Color.parseColor(HEX_HIGHLIGHT));
                ds.setUnderlineText(false);
                ds.setFakeBoldText(true);
            }
        }, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private static int dpToPx(Context c, int dp) {
        return (int) (dp * c.getResources().getDisplayMetrics().density);
    }

    private static void openUrl(Context ctx, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception e) {}
    }
}